
To run the RestAPI the URL should be http://localhost:8080/score

This project was tested with Gradle 6.6.1. If in doubt, check your Gradle version in both Eclipse and at the command line.


The gradle version varies from project vm to labs vm.

gradle --version

Upon import into Eclipse, you may need to right-click on the project and select Enable Gradle Facet.

