package com.mcnz.rps;

public class Score {
	
	public int wins, losses, ties;

}
